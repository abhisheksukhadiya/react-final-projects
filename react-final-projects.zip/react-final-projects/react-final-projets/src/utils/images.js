import slider_img_1 from "../assets/images/slider_img_1.jpg";
import slider_img_2 from "../assets/images/slider_img_2.jpg";
import shopping_cart from "../assets/images/shopping_cart.png";
import correct from "../assets/images/correct.png";
import loader from "../assets/images/loader.svg";
 
const sliderImgs = [slider_img_1, slider_img_2];
export {sliderImgs, shopping_cart, correct, loader};
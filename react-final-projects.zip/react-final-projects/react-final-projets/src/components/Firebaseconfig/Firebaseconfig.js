// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBZy6BS8MtUAsA0Pjq4A8GiFV6zxC0ZvMs",
  authDomain: "react-final-projects.firebaseapp.com",
  projectId: "react-final-projects",
  storageBucket: "react-final-projects.appspot.com",
  messagingSenderId: "783451496755",
  appId: "1:783451496755:web:9179a117c14a5461061e46",
  measurementId: "G-WTH3EXW2PN"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);